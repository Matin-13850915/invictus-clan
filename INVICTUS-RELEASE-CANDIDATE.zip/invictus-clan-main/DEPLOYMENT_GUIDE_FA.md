# راهنمای استقرار INVICTUS روی GitHub Pages و Firebase

## ۱) بارگذاری در GitHub

1. فایل ZIP را استخراج کنید.
2. وارد مخزن `invictus-clan` شوید.
3. `Add file` → `Upload files` را انتخاب کنید.
4. محتویات داخل پوشه `invictus-clan-main` را انتخاب کنید؛ خود پوشه‌ی اضافی را داخل مخزن تودرتو نکنید.
5. اگر GitHub پرسید فایل‌های موجود جایگزین شوند، فقط وقتی ادامه دهید که مطمئنید مخزن همان پروژه است.
6. پایین صفحه `Commit changes` را بزنید.

ساختار ریشه مخزن باید شبیه این باشد:

```text
index.html
README.md
assets/
  css/style.css
  js/app.js
  js/firebase.js
  js/database.js
  ...
```

## ۲) فعال‌سازی Firebase Authentication

1. Firebase Console را باز کنید و پروژه `invictus-eec12` را انتخاب کنید.
2. Authentication → Sign-in method را باز کنید.
3. Email/Password را فعال کنید.
4. در Authentication → Users، حساب‌های موردنیاز را ایجاد کنید.
5. برای هر حساب UID را کپی کنید؛ UID را با ایمیل یا نام کاربری اشتباه نگیرید.

## ۳) تعریف نقش‌ها در Realtime Database

در Realtime Database → Data برای هر UID رکورد زیر را بسازید:

مسیر: `roles/UID_کاربر`

```json
{
  "role": "member",
  "active": true,
  "specialty": null
}
```

مقادیر role: `admin`, `leader`, `tester`, `member`.

برای تستر:

```json
{
  "role": "tester",
  "active": true,
  "specialty": "MP"
}
```

یا مقدار `BR`.

مدیر اصلی در کد فعلی UID زیر است و باید رکورد admin فعال داشته باشد:

`kxaAoKgm5WUxqsV9hoAk75XQuL43`

**نکته:** برنامه فعلی خودش حساب Firebase Authentication ایجاد نمی‌کند. حساب را از Firebase Console بسازید و سپس نقش را در دیتابیس ثبت کنید. لینک بازیابی رمز از فرم ورود کار می‌کند، مشروط به فعال بودن Email/Password.

## ۴) مجازکردن دامنه GitHub Pages

1. بعد از فعال‌کردن GitHub Pages، آدرس نهایی سایت را بردارید.
2. Firebase Console → Authentication → Settings → Authorized domains را باز کنید.
3. دامنه میزبان را اضافه کنید؛ معمولاً فقط hostname مانند `username.github.io` لازم است، نه مسیر `/invictus-clan`.
4. سایت را با HTTPS باز کنید.

## ۵) انتشار GitHub Pages

مخزن → Settings → Pages:

- Source: Deploy from a branch
- Branch: `main`
- Folder: `/ (root)`
- Save

پس از چند دقیقه آدرس Pages در همان بخش نمایش داده می‌شود.

## ۶) چک‌لیست تست پس از انتشار

- [ ] صفحه ورود بدون خطای JavaScript باز می‌شود.
- [ ] ورود مدیر اصلی انجام می‌شود.
- [ ] نقش مدیر در کنار نام نمایش داده می‌شود.
- [ ] خروج از حساب کار می‌کند.
- [ ] بازیابی رمز ایمیل می‌فرستد.
- [ ] حساب عضو فقط منوهای مجاز خود را می‌بیند.
- [ ] حساب تستر منوهای غیرمجاز را نمی‌بیند.
- [ ] مسیرهای Firebase برای نقش‌های غیرمجاز با Rules رد می‌شوند.
- [ ] ایجاد/ویرایش/حذف رکورد فقط با حساب مجاز ممکن است.
- [ ] پیام خصوصی و تیکت فقط برای مالک و کارکنان مجاز قابل خواندن است.
- [ ] سایت روی گوشی و مرورگر دسکتاپ بررسی می‌شود.

## امنیت و Rules

فایل `FIREBASE_RULES_TEMPLATE.json` را بدون بررسی ساختار داده‌ها روی دیتابیس اصلی Deploy نکنید. مخصوصاً دسترسی خواندن عمومی به پیام خصوصی، چت، تیکت، گزارش‌ها و اطلاعات کاربران خطرناک است. ابتدا از دیتابیس Export/Backup بگیرید و قواعد را در پروژه آزمایشی تست کنید. کنترل نقش در `app.js` صرفاً برای رابط کاربری است؛ مجوز واقعی باید در Security Rules اعمال شود.
