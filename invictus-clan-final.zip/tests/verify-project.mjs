import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const jsRoot = path.join(root, "assets", "js");
const errors = [];
const jsFiles = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && full.endsWith(".js")) jsFiles.push(full);
  }
}
walk(jsRoot);

for (const file of jsFiles) {
  const check = spawnSync(process.execPath, ["--check", file], {
    cwd: root,
    encoding: "utf8"
  });
  if (check.status !== 0) {
    errors.push(`Syntax: ${path.relative(root, file)}\n${check.stderr}`);
  }

  const source = fs.readFileSync(file, "utf8");
  const importPattern = /(?:from\s*|import\s*)["']([^"']+)["']/g;
  for (const match of source.matchAll(importPattern)) {
    const specifier = match[1];
    if (!specifier.startsWith(".")) continue;
    const resolved = path.resolve(path.dirname(file), specifier);
    const candidates = [resolved, `${resolved}.js`, path.join(resolved, "index.js")];
    if (!candidates.some(candidate => fs.existsSync(candidate))) {
      errors.push(`Missing import: ${path.relative(root, file)} -> ${specifier}`);
    }
  }
}

const exportMap = new Map();
for (const file of jsFiles) {
  const source = fs.readFileSync(file, "utf8");
  const names = new Set();
  for (const match of source.matchAll(/export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)/g)) {
    names.add(match[1]);
  }
  for (const block of source.matchAll(/export\s*\{([^}]+)\}/gs)) {
    for (const part of block[1].split(",")) {
      const name = part.trim().split(/\s+as\s+/)[0].trim();
      if (/^[A-Za-z_$][\w$]*$/.test(name)) names.add(name);
    }
  }
  exportMap.set(file, names);
}
for (const file of jsFiles) {
  const source = fs.readFileSync(file, "utf8");
  for (const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*["']([^"']+)["']/gs)) {
    const specifier = match[2];
    if (!specifier.startsWith(".")) continue;
    let target = path.resolve(path.dirname(file), specifier);
    if (!fs.existsSync(target) && fs.existsSync(`${target}.js`)) target += ".js";
    if (!fs.existsSync(target)) continue;
    const exported = exportMap.get(target) || new Set();
    for (const part of match[1].split(",")) {
      const imported = part.trim().split(/\s+as\s+/)[0].trim();
      if (imported && !exported.has(imported)) {
        errors.push(`Missing named export: ${path.relative(root, file)} imports ${imported} from ${path.relative(root, target)}`);
      }
    }
  }
}

const rulesPath = path.join(root, "database.rules.json");
try {
  const rules = JSON.parse(fs.readFileSync(rulesPath, "utf8"));
  if (!rules.rules || rules.rules[".read"] !== "false" || rules.rules[".write"] !== "false") {
    errors.push("Database rules must deny root-level read and write.");
  }
} catch (error) {
  errors.push(`Invalid database.rules.json: ${error.message}`);
}

const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
for (const asset of ["assets/css/style.css", "assets/js/app.js"]) {
  if (!fs.existsSync(path.join(root, asset)) || !html.includes(asset)) {
    errors.push(`Missing HTML asset: ${asset}`);
  }
}

const app = fs.readFileSync(path.join(jsRoot, "app.js"), "utf8");
const renderBlock = app.match(/const renderFunctions\s*=\s*\{([\s\S]*?)\};/);
if (!renderBlock) {
  errors.push("Could not locate route renderer map.");
} else {
  const pageRoutes = [...renderBlock[1].matchAll(/(\w+):\s*"(\w+)"/g)];
  for (const [ , page, exportName ] of pageRoutes) {
    const pageFile = page === "support" ? "bug-reports.js"
      : page === "staff" || page === "activity" ? "activity.js"
      : `${page}.js`;
    const target = path.join(jsRoot, "pages", pageFile);
    if (!fs.existsSync(target)) {
      errors.push(`Missing page module for route ${page}: ${pageFile}`);
      continue;
    }
    const source = fs.readFileSync(target, "utf8");
    if (!new RegExp(`export\\s+(?:async\\s+)?function\\s+${exportName}\\b`).test(source)) {
      errors.push(`Missing route export ${exportName} in ${pageFile}`);
    }
  }
}

if (errors.length) {
  console.error(`FAILED: ${errors.length} issue(s)`);
  for (const error of errors) console.error(`\n- ${error}`);
  process.exit(1);
}

console.log(`PASS: ${jsFiles.length} JavaScript files parsed.`);
console.log("PASS: Relative module imports resolve.");
console.log("PASS: All application routes map to exported render functions.");
console.log("PASS: Firebase rules JSON is valid and root access is denied.");
console.log("PASS: HTML entry assets exist.");
