import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

const temp = fs.mkdtempSync(path.join(os.tmpdir(), "invictus-smoke-"));
const jsDir = path.join(temp, "assets", "js");
fs.mkdirSync(jsDir, { recursive: true });

const sourceRoot = path.resolve("assets/js");
for (const file of [
  "teams.js",
  "application-tracker.js",
  "private-messages.js",
  "rewards.js",
  "profile.js",
  "utils.js"
]) {
  fs.copyFileSync(path.join(sourceRoot, file), path.join(jsDir, file));
}

const databaseStub = `
const store = {};
let sequence = 0;
const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
function parts(path) { return path.split("/").filter(Boolean); }
function get(path) {
  let value = store;
  for (const key of parts(path)) {
    if (!value || typeof value !== "object") return null;
    value = value[key];
  }
  return value === undefined ? null : value;
}
function set(path, value) {
  const keys = parts(path);
  let node = store;
  for (const key of keys.slice(0, -1)) node = node[key] ||= {};
  const last = keys.at(-1);
  if (value === null) delete node[last];
  else node[last] = clone(value);
}
function merge(path, values) {
  for (const [key, value] of Object.entries(values || {})) {
    set(path + "/" + key, value);
  }
}
export function seed(path, value) { set(path, value); }
export function dump(path) { return clone(get(path)); }
export async function readData(path) { return clone(get(path)); }
export async function getRecord(path) {
  const value = get(path);
  if (value == null) return null;
  if (typeof value === "object" && !Array.isArray(value)) {
    return { ...clone(value), id: value.id || parts(path).at(-1) };
  }
  return clone(value);
}
export async function getAllRecords(path) {
  const value = get(path);
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  return Object.entries(value).filter(([, item]) => item != null)
    .map(([id, item]) => ({ ...(item && typeof item === "object" ? clone(item) : { value: item }), id }));
}
export async function createRecord(path, value) {
  const id = "rec_" + (++sequence);
  set(path + "/" + id, { ...clone(value), createdAt: value.createdAt ?? Date.now(), updatedAt: value.updatedAt ?? Date.now() });
  return id;
}
export async function updateData(path, values) {
  for (const [key, value] of Object.entries(values || {})) set(path + "/" + key, value);
  return true;
}
export async function updateMultipleData(values) {
  for (const [path, value] of Object.entries(values || {})) set(path, value);
  return true;
}
export async function updateRecord(path, values) { return updateData(path, values); }
export async function deleteData(path) { set(path, null); return true; }
export async function findByField(path, field, value) {
  return (await getAllRecords(path)).filter(item => item[field] === value);
}
`;
fs.writeFileSync(path.join(jsDir, "database.js"), databaseStub);


const firebaseStub = `
const store = globalThis.__invictusFirebaseStore ||= {};
export const auth = { currentUser: null };
export const db = {};
export const ref = (_db, path) => ({ path });
function read(path) {
  let value = store;
  for (const key of path.split("/")) value = value && value[key];
  return value === undefined ? null : value;
}
function write(path, value) {
  const keys = path.split("/");
  let node = store;
  for (const key of keys.slice(0, -1)) node = node[key] ||= {};
  node[keys.at(-1)] = value;
}
export async function get(reference) {
  const value = read(reference.path);
  return { exists: () => value !== null, val: () => value };
}
export async function update(_reference, updates) {
  for (const [path, value] of Object.entries(updates)) write(path, value);
}
export async function createUserWithEmailAndPassword(_auth, email, password) {
  if (password.length < 8) throw new Error("weak password");
  const user = { uid: "new_member_123456", email, displayName: "" };
  auth.currentUser = user;
  return { user };
}
export async function updateProfile(user, values) { Object.assign(user, values); }
export async function deleteUser(user) {
  user.deleted = true;
  if (auth.currentUser?.uid === user.uid) auth.currentUser = null;
}
export async function signOut() { auth.currentUser = null; }
export function onAuthStateChanged(_auth, callback) { callback(auth.currentUser); return () => {}; }
export async function signInWithEmailAndPassword() { throw new Error("unused"); }
export async function sendPasswordResetEmail() { return true; }
`;
fs.writeFileSync(path.join(jsDir, "firebase.js"), firebaseStub);
fs.copyFileSync(path.join(sourceRoot, "auth.js"), path.join(jsDir, "auth.js"));
const authModule = await import(pathToFileURL(path.join(jsDir, "auth.js")));
const encodedEmail = "new%2Emember%40example%2Ecom";
globalThis.__invictusFirebaseStore.approvedApplications ||= {};
globalThis.__invictusFirebaseStore.approvedApplications[encodedEmail] = {
  applicationId: "app_approved_1",
  email: "new.member@example.com",
  status: "accepted",
  claimedUid: null,
  realName: "New Member",
  gameName: "NewMemberCODM",
  gameLevel: 180
};
const activatedUser = await authModule.createApprovedAccount(
  "new.member@example.com",
  "strong-pass-123"
);
assert.equal(activatedUser.uid, "new_member_123456");
assert.equal(globalThis.__invictusFirebaseStore.roles.new_member_123456.role, "member");
assert.equal(globalThis.__invictusFirebaseStore.users.new_member_123456.email, "new.member@example.com");
assert.equal(globalThis.__invictusFirebaseStore.publicProfiles.new_member_123456.gameName, "NewMemberCODM");
assert.equal(globalThis.__invictusFirebaseStore.approvedApplications[encodedEmail].claimedUid, "new_member_123456");
console.log("PASS: Approved applicant account activation, role/profile creation and one-time claim.");

const db = await import(pathToFileURL(path.join(jsDir, "database.js")));
const teams = await import(pathToFileURL(path.join(jsDir, "teams.js")));
const tracker = await import(pathToFileURL(path.join(jsDir, "application-tracker.js")));
const messages = await import(pathToFileURL(path.join(jsDir, "private-messages.js")));
const rewards = await import(pathToFileURL(path.join(jsDir, "rewards.js")));
const profile = await import(pathToFileURL(path.join(jsDir, "profile.js")));

const admin = { uid: "admin_123456789", role: "admin", active: true, status: "active" };
const leader = { uid: "leader_123456", role: "leader", active: true, status: "active" };
const member = { uid: "member_123456", role: "member", active: true, status: "active", displayName: "Member One" };
const member2 = { uid: "member_654321", role: "member", active: true, status: "active", displayName: "Member Two" };
const tester = { uid: "tester_123456", role: "tester", active: true, status: "active", specialty: "MP" };

for (const person of [admin, leader, member, member2, tester]) {
  db.seed("roles/" + person.uid, { role: person.role, active: true, status: "active", specialty: person.specialty || null });
  db.seed("publicProfiles/" + person.uid, { displayName: person.displayName || person.role, gameName: person.displayName || person.role });
}

const teamId = await teams.createTeam({
  name: "INVICTUS Alpha",
  description: "MP squad",
  type: "MP",
  captainUid: member.uid
}, leader);
assert.ok(teamId);
await teams.addTeamMember(teamId, member2.uid, leader);
await teams.setTeamCaptain(teamId, member2.uid, leader);
let listedTeams = await teams.getTeams();
assert.equal(listedTeams.length, 1);
assert.equal(listedTeams[0].captainUid, member2.uid);
assert.equal(Object.keys(listedTeams[0].members).length, 2);
await teams.removeTeamMember(teamId, member.uid, leader);
await teams.deactivateTeam(teamId, leader);
assert.equal((await teams.getTeams()).length, 0);
assert.equal((await teams.getTeams({ includeInactive: true }, leader)).length, 1);
await teams.activateTeam(teamId, leader);
await teams.deleteTeam(teamId, admin);
assert.equal((await teams.getTeams()).length, 0);
console.log("PASS: Team CRUD, membership, captain and active-state workflow.");

const applicationId = await tracker.createApplication({
  realName: "Applicant",
  email: "applicant@example.com",
  gameName: "ApplicantCODM",
  gameLevel: 250,
  applicationType: "MP",
  mpRank: "Legendary",
  contactType: "telegram",
  contactValue: "@applicant",
  brRank: "",
  telegram: "@applicant",
  rubika: "",
  description: "Test application"
}, member);
assert.ok(applicationId);
await tracker.assignApplicationTester(applicationId, tester.uid, "MP", leader);
const assigned = await tracker.getApplications(tester);
assert.equal(assigned.length, 1);
assert.equal(assigned[0].id, applicationId);
await tracker.startApplicationTest(applicationId, tester);
await tracker.submitTestResult(applicationId, "recommended", "Test passed", tester);
await tracker.decideApplication(applicationId, "accepted", "Approved", leader);
const approved = db.dump("approvedApplications/applicant%40example%2Ecom");
assert.equal(approved.status, "accepted");
assert.equal(approved.applicationId, applicationId);
assert.equal((await tracker.getApplications(leader))[0].status, "accepted");
console.log("PASS: Recruitment, tester assignment, test result and leader approval workflow.");

await messages.sendPrivateMessage(member2.uid, "Hello from member one", member);
let conversationMessages = await messages.getConversationMessages(member2.uid, member);
assert.equal(conversationMessages.length, 1);
assert.equal(conversationMessages[0].senderUid, member.uid);
await messages.editPrivateMessage(member2.uid, conversationMessages[0].id, "Edited message", member);
conversationMessages = await messages.getConversationMessages(member2.uid, member);
assert.equal(conversationMessages[0].text, "Edited message");
await messages.deletePrivateMessage(member2.uid, conversationMessages[0].id, member);
assert.equal((await messages.getConversationMessages(member2.uid, member)).length, 0);
console.log("PASS: New private conversation, message read, edit and delete.");

db.seed("rewards/reward_1", { title: "Clan Badge", cost: 50, stock: 2, active: true });
db.seed("pointBalances/" + member.uid, { balance: 120 });
const requestId = await rewards.requestReward("reward_1", member);
assert.ok(requestId);
await rewards.reviewRewardRequest(requestId, "approved", admin, "Approved");
assert.equal(db.dump("pointBalances/" + member.uid).balance, 70);
assert.equal(db.dump("rewards/reward_1").stock, 1);
assert.equal(db.dump("rewardRequests/" + requestId).status, "approved");
console.log("PASS: Reward request, approval, balance deduction and stock update.");

db.seed("users/" + member.uid, {
  uid: member.uid,
  email: "member@example.com",
  displayName: "Member One",
  gameName: "OldName",
  telegram: "@private"
});
db.seed("publicProfiles/" + member.uid, {
  uid: member.uid,
  displayName: "Member One",
  gameName: "OldName"
});
await profile.updateOwnProfile(member.uid, {
  displayName: "Member Updated",
  gameName: "NewName",
  telegram: "@newprivate",
  bio: "Public bio"
}, member);
assert.equal(db.dump("users/" + member.uid).telegram, "@newprivate");
assert.equal(db.dump("publicProfiles/" + member.uid).gameName, "NewName");
assert.equal(db.dump("publicProfiles/" + member.uid).telegram, undefined);
assert.equal((await profile.getPublicProfile(member.uid)).displayName, "Member Updated");
console.log("PASS: Private profile updates sync only public-safe fields to publicProfiles.");

fs.rmSync(temp, { recursive: true, force: true });
console.log("PASS: All service smoke tests completed.");
